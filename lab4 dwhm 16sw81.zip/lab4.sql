/*
SQLyog Ultimate v11.11 (64 bit)
MySQL - 5.6.21 : Database - lab4
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`lab4` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `lab4`;

/*Table structure for table `customer` */

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `customer` */

insert  into `customer`(`customer_id`,`customer_name`) values (1,'Vijay'),(2,'Mehdi'),(3,'Saad'),(4,'Sameer');

/*Table structure for table `dummy_table` */

DROP TABLE IF EXISTS `dummy_table`;

CREATE TABLE `dummy_table` (
  `dummny_id` int(11) NOT NULL AUTO_INCREMENT,
  `dummny_result_title` varchar(255) DEFAULT NULL,
  `dummy_result` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`dummny_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `dummy_table` */

insert  into `dummy_table`(`dummny_id`,`dummny_result_title`,`dummy_result`) values (1,'Total Sale of Month','7000'),(2,'Profit','-1223000'),(3,'Highest Selling Product','Cold Drink'),(4,'Lowest Selling Product','Soap');

/*Table structure for table `expenditure` */

DROP TABLE IF EXISTS `expenditure`;

CREATE TABLE `expenditure` (
  `exp_id` int(11) NOT NULL AUTO_INCREMENT,
  `exp_type` varchar(255) DEFAULT NULL,
  `exp_amount` int(11) DEFAULT NULL,
  `exp_date` date DEFAULT NULL,
  PRIMARY KEY (`exp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `expenditure` */

insert  into `expenditure`(`exp_id`,`exp_type`,`exp_amount`,`exp_date`) values (1,'Rent',1200000,'2019-05-07'),(2,'Utility bills',30000,'2019-05-07');

/*Table structure for table `order` */

DROP TABLE IF EXISTS `order`;

CREATE TABLE `order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `order_total` int(11) DEFAULT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `order` */

insert  into `order`(`order_id`,`customer_id`,`order_date`,`order_total`) values (1,1,'2019-05-07',5000),(2,2,'2019-05-07',2000);

/*Table structure for table `order_details` */

DROP TABLE IF EXISTS `order_details`;

CREATE TABLE `order_details` (
  `order_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `order_quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`order_detail_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `order_details` */

insert  into `order_details`(`order_detail_id`,`order_id`,`product_id`,`order_quantity`) values (1,1,1,100),(2,2,2,10);

/*Table structure for table `product` */

DROP TABLE IF EXISTS `product`;

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) DEFAULT NULL,
  `product_qty` int(11) DEFAULT NULL,
  `product_unit` int(11) DEFAULT NULL,
  `product_retail` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `product` */

insert  into `product`(`product_id`,`product_name`,`product_qty`,`product_unit`,`product_retail`) values (1,'Cold Drink',500,8,10),(2,'Soap',10,90,10);

/*Table structure for table `report_table` */

DROP TABLE IF EXISTS `report_table`;

CREATE TABLE `report_table` (
  `total_expenditure` double(16,4) DEFAULT NULL,
  `total_product` double(16,4) DEFAULT NULL,
  `owner_investment` double(16,4) DEFAULT NULL,
  `sell` double(16,4) DEFAULT NULL,
  `profit` double(16,4) DEFAULT NULL,
  `highest_sell_prod` double(16,4) DEFAULT NULL,
  `lowest_sell_prod` double(16,4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `report_table` */

/* Procedure structure for procedure `reportProced` */

/*!50003 DROP PROCEDURE IF EXISTS  `reportProced` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `reportProced`()
BEGIN
SELECT  @total_sale_in_month:= SUM(order_total) FROM `order` where `order_date` between  '2019-04-08' and '2019-05-08' ;
SELECT  @exp:= SUM(`exp_amount`) FROM `expenditure` WHERE `exp_date` BETWEEN  '2019-04-08' AND '2019-05-08' ;
SELECT  @profit:= @total_sale_in_month-@exp;
SELECT  @higest_saling_product:= p.`product_name` FROM order_details o INNER JOIN product p ON p.product_id=o.product_id  WHERE o.order_quantity=(SELECT MAX(order_quantity) FROM order_details);
SELECT  @lowest_saling_product:= p.`product_name` FROM order_details o INNER JOIN product p ON p.product_id=o.product_id  WHERE o.order_quantity=(SELECT Min(order_quantity) FROM order_details);
		
		
INSERT INTO `dummy_table` VALUES('','Total Sale of Month',@total_sale_in_month )
		,('','Profit',@profit),('','Highest Selling Product',@higest_saling_product),
		('','Lowest Selling Product',@lowest_saling_product);
		
		select * from `dummy_table`;
	
    END */$$
DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
