/*
SQLyog Ultimate v11.11 (64 bit)
MySQL - 5.6.21 : Database - lab2
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`lab2` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `lab2`;

/*Table structure for table `activity` */

DROP TABLE IF EXISTS `activity`;

CREATE TABLE `activity` (
  `activity_id` int(11) NOT NULL AUTO_INCREMENT,
  `activity_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`activity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `activity` */

insert  into `activity`(`activity_id`,`activity_name`) values (1,'Sports'),(2,'English Langauage'),(3,'Reseaching'),(4,'volunteer work');

/*Table structure for table `book` */

DROP TABLE IF EXISTS `book`;

CREATE TABLE `book` (
  `isbn_number` varchar(30) NOT NULL,
  `title` varchar(30) DEFAULT NULL,
  `price` double(16,4) DEFAULT NULL,
  `date_of_publication` date DEFAULT NULL,
  `publisher_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`isbn_number`),
  KEY `publisher_id` (`publisher_id`),
  CONSTRAINT `book_ibfk_1` FOREIGN KEY (`publisher_id`) REFERENCES `publisher` (`publisher_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `book` */

insert  into `book`(`isbn_number`,`title`,`price`,`date_of_publication`,`publisher_id`) values ('','Media Manipulator',6500.0000,'2019-04-18',1),('11191968680-ISO','The Meg  ',NULL,NULL,3),('21191968680-ISO','Asperger’s Rules!',1000.0000,'2018-02-13',1),('2191968680-ISO','The Life',NULL,NULL,1),('9191968680-ISO','Media Manipulator',2100.0000,'2019-01-14',2),('956868680-ISO','Freakonomics',8900.0000,'2018-12-10',5);

/*Table structure for table `college_course` */

DROP TABLE IF EXISTS `college_course`;

CREATE TABLE `college_course` (
  `course_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_name` varchar(255) DEFAULT NULL,
  `units` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `college_course` */

insert  into `college_course`(`course_id`,`course_name`,`units`) values (1,'DC','1'),(2,'AICT','2'),(3,'WT','6'),(4,'IMSG','4'),(5,'CV','1');

/*Table structure for table `designer` */

DROP TABLE IF EXISTS `designer`;

CREATE TABLE `designer` (
  `desginer_id` int(11) NOT NULL AUTO_INCREMENT,
  `designer_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`desginer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `designer` */

insert  into `designer`(`desginer_id`,`designer_name`) values (1,'Ali'),(2,'Mehdi'),(3,'Saad'),(4,'Usama'),(5,'Awais');

/*Table structure for table `hospitaldata` */

DROP TABLE IF EXISTS `hospitaldata`;

CREATE TABLE `hospitaldata` (
  `Facility` varchar(30) NOT NULL,
  `Physician` varchar(30) NOT NULL,
  `Ward` varchar(30) NOT NULL,
  `Patient` varchar(30) NOT NULL,
  `Diagnostic unit` varchar(30) NOT NULL,
  `Order` varchar(30) NOT NULL,
  `Supply item` varchar(30) NOT NULL,
  `Vendor` varchar(30) NOT NULL,
  `Service Drug` varchar(30) NOT NULL,
  `Medical item` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hospitaldata` */

insert  into `hospitaldata`(`Facility`,`Physician`,`Ward`,`Patient`,`Diagnostic unit`,`Order`,`Supply item`,`Vendor`,`Service Drug`,`Medical item`) values ('Lift in Hospital','Dr Ayaz','Obstetrics','Ibrar','radiology','2','Box aweeper','House keeping','lipid profile','MRIs '),('Provide Room for patient','Dr Imran','Oncology','Ali','Clinical Laboratory','2','Basket','Maintainence Purpose','CBC','X-rays'),('Lift in Hospital','Dr Ayaz','Obstetrics','Ibrar','radiology','2','Box aweeper','House keeping','lipid profile','MRIs '),('Provide Room for patient','Dr Imran','Oncology','Ali','Clinical Laboratory','2','Basket','Maintainence Purpose','CBC','X-rays');

/*Table structure for table `model` */

DROP TABLE IF EXISTS `model`;

CREATE TABLE `model` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `serial_num` int(11) DEFAULT NULL,
  `designer_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `serial_num` (`serial_num`),
  KEY `designer_id` (`designer_id`),
  CONSTRAINT `model_ibfk_1` FOREIGN KEY (`serial_num`) REFERENCES `piano` (`serial_num`),
  CONSTRAINT `model_ibfk_2` FOREIGN KEY (`designer_id`) REFERENCES `designer` (`desginer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `model` */

insert  into `model`(`id`,`name`,`serial_num`,`designer_id`) values (1,'FG432',1,2),(2,'FJ212',2,1),(3,'KJ122',3,1),(4,'LI1212',3,2),(8,'LI122',4,4);

/*Table structure for table `piano` */

DROP TABLE IF EXISTS `piano`;

CREATE TABLE `piano` (
  `serial_num` int(11) NOT NULL AUTO_INCREMENT,
  `mfg_completion_date` date DEFAULT NULL,
  `emp_num` int(11) DEFAULT NULL,
  PRIMARY KEY (`serial_num`),
  KEY `emp_num` (`emp_num`),
  CONSTRAINT `piano_ibfk_1` FOREIGN KEY (`emp_num`) REFERENCES `techinican` (`emp_num`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `piano` */

insert  into `piano`(`serial_num`,`mfg_completion_date`,`emp_num`) values (1,'2019-04-18',1),(2,'2019-01-15',2),(3,'2010-04-19',2),(4,'1957-03-06',4),(5,'2013-04-08',NULL);

/*Table structure for table `publisher` */

DROP TABLE IF EXISTS `publisher`;

CREATE TABLE `publisher` (
  `publisher_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) DEFAULT NULL,
  `number` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`publisher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `publisher` */

insert  into `publisher`(`publisher_id`,`name`,`number`) values (1,'Asif','03332398123'),(2,'John Wick','0302548794'),(3,'Watson','03245474894'),(4,'Johnson','03145474897'),(5,'Johnny','0334545875');

/*Table structure for table `schedule_section` */

DROP TABLE IF EXISTS `schedule_section`;

CREATE TABLE `schedule_section` (
  `semister_id` int(11) NOT NULL AUTO_INCREMENT,
  `section_num` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`semister_id`),
  KEY `course_id` (`course_id`),
  CONSTRAINT `schedule_section_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `college_course` (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `schedule_section` */

insert  into `schedule_section`(`semister_id`,`section_num`,`course_id`) values (1,1,1),(2,1,1),(3,1,2);

/*Table structure for table `student` */

DROP TABLE IF EXISTS `student`;

CREATE TABLE `student` (
  `student_phone` varchar(20) NOT NULL,
  `student_name` varchar(50) DEFAULT NULL,
  `address` varchar(20) DEFAULT NULL,
  `age` int(5) DEFAULT NULL,
  `no_of_years` int(20) DEFAULT NULL,
  PRIMARY KEY (`student_phone`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `student` */

insert  into `student`(`student_phone`,`student_name`,`address`,`age`,`no_of_years`) values ('','Humza','Hyd',22,4),('03005478741','Yousha','Karachi',22,4),('03025548889','Usama','Hyd',24,4),('03214569888','Mehdi','Tando Jam',22,4),('0333256487','Saad','Hyd',22,4);

/*Table structure for table `student_activity` */

DROP TABLE IF EXISTS `student_activity`;

CREATE TABLE `student_activity` (
  `student_phone` varchar(20) DEFAULT NULL,
  `activity_id` int(11) DEFAULT NULL,
  KEY `activity_id` (`activity_id`),
  KEY `student_phone` (`student_phone`),
  CONSTRAINT `student_activity_ibfk_2` FOREIGN KEY (`activity_id`) REFERENCES `activity` (`activity_id`),
  CONSTRAINT `student_activity_ibfk_3` FOREIGN KEY (`student_phone`) REFERENCES `student` (`student_phone`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `student_activity` */

/*Table structure for table `techinican` */

DROP TABLE IF EXISTS `techinican`;

CREATE TABLE `techinican` (
  `emp_num` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `superiver_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`emp_num`),
  KEY `superiver_id` (`superiver_id`),
  CONSTRAINT `techinican_ibfk_1` FOREIGN KEY (`superiver_id`) REFERENCES `techinican` (`emp_num`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `techinican` */

insert  into `techinican`(`emp_num`,`name`,`superiver_id`) values (1,'Raza',1),(2,'Asif',5),(3,'Kashif',1),(4,'Zaruab',5),(5,'Ali',NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
