/*
SQLyog Ultimate v11.11 (64 bit)
MySQL - 5.6.21 : Database - lab3
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`lab3` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `lab3`;

/*Table structure for table `delay_reason` */

DROP TABLE IF EXISTS `delay_reason`;

CREATE TABLE `delay_reason` (
  `reason_code` varchar(11) CHARACTER SET latin1 NOT NULL,
  `name` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`reason_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `delay_reason` */

insert  into `delay_reason`(`reason_code`,`name`) values ('S','NoSpare'),('V','Vendor');

/*Table structure for table `down_reason` */

DROP TABLE IF EXISTS `down_reason`;

CREATE TABLE `down_reason` (
  `reason_code` varchar(11) CHARACTER SET latin1 NOT NULL,
  `name` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`reason_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `down_reason` */

insert  into `down_reason`(`reason_code`,`name`) values ('B','Broken Part'),('H','Over Heated');

/*Table structure for table `event` */

DROP TABLE IF EXISTS `event`;

CREATE TABLE `event` (
  `event_id` int(11) NOT NULL AUTO_INCREMENT,
  `duration` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `status_code` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `reason_code` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

/*Data for the table `event` */

insert  into `event`(`event_id`,`duration`,`status_code`,`reason_code`) values (1,'5','R','S'),(2,'60','D1','S'),(3,'10','S','C'),(4,'20','D2','H'),(5,'15','5','H'),(6,'25','D1','V'),(7,'20','R','S'),(8,'60','D2','B');

/*Table structure for table `ready_reason` */

DROP TABLE IF EXISTS `ready_reason`;

CREATE TABLE `ready_reason` (
  `reason_code` varchar(11) CHARACTER SET latin1 NOT NULL,
  `name` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`reason_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `ready_reason` */

insert  into `ready_reason`(`reason_code`,`name`) values ('R','Running'),('S','Standby');

/*Table structure for table `spare_reason` */

DROP TABLE IF EXISTS `spare_reason`;

CREATE TABLE `spare_reason` (
  `reason_code` varchar(11) CHARACTER SET latin1 NOT NULL,
  `name` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`reason_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `spare_reason` */

insert  into `spare_reason`(`reason_code`,`name`) values ('C','Cold Spare'),('H ','Hot Spare');

/*Table structure for table `status` */

DROP TABLE IF EXISTS `status`;

CREATE TABLE `status` (
  `status_code` varchar(11) CHARACTER SET latin1 NOT NULL,
  `name` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`status_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `status` */

insert  into `status`(`status_code`,`name`) values ('D1','Delay'),('D2','Down'),('R','Ready'),('S','Spare');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
